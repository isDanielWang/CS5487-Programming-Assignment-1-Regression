This archive contains the text versions of the MATLAB mat data files.
Each file is one matrix or vector.

** Important Note **
The number format is 16-digit double, and tab delimited.
The matrices are transposed in the text file.  
That is, each row in the text file corresponds to a column of a matrix.

So if the file contains:

1 2 3 4
5 6 7 8

Then this is actually a 4 x 2 matrix:
  1 5
  2 6
  3 7 
  4 8

